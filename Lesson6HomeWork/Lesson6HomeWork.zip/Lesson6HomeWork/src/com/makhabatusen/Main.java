package com.makhabatusen;

public class Main {

    public static void main(String[] args) {

        /*
         Создать обобщенный класс и обобщенный интерфейс и реализовать этот интерфейс классом.
         Ограничить параметры типов классом Number. В главном классе создать несколько экземпляров
         обобщенного класса.*/

        CurrencyExchanger<Integer> currencyExchanger = new CurrencyExchanger <>(78);
        currencyExchanger.convert(7638);

        CurrencyExchanger<Double> currencyExchanger2 = new CurrencyExchanger<>(36.65);
        currencyExchanger2.convert(45673);

        CurrencyExchanger<Float> currencyExchanger3 = new CurrencyExchanger <>(39.4523F);
        currencyExchanger3.convert(980.5215876);
    }
}