package com.makhabatusen;

public interface Convertible<T extends Number> {

     void convert(T amount);

}
